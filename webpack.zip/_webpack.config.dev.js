var path = require('path');
var webpack = require('webpack');
var Config = require('./webpack.config.js');
const ExtractTextPlugin = require("extract-text-webpack-plugin");

Config.devtool = 'cheap-module-source-map';

Config.plugins = (Config.plugins || []).concat([
	new webpack.DefinePlugin({
		'process.env': {
			'NODE_ENV': '"development"',
		}
	}),
	new ExtractTextPlugin({
		disable: true
	})
]);

Config.watch = true;

Config.devtool = 'cheap-eval-source-map';

Config.devServer = {
	contentBase: __dirname,
	publicPath: "/",
	hot: true,
	open: true
};

module.exports = Config;