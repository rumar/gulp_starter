'use strict';

// console.log(process.env.NODE_ENV);
require ("./../sass/common.scss");